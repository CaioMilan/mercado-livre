const makita = document.getElementById("card")

const imagem = ["./Makita.jfif", "./Martelo.jfif", "./Philips.webp", "./Frozen.webp", "Batman.jfif", "Boneca.jfif"]
const nome = ["Makita", "Martelo", "Chave philips", "Fantasia Frozen", "Fantasia Batman", "Vó de quem está lendo"]
const info = ["xxxxxxxxxxxxxxxxxxxxxx", "xxxxxxxxxxxxxxxxxxxxxxxxx", "xxxxxxxxxxxxxxxxxxxxxx", "xxxxxxxxxxxxxxxxxxxxxxxx", "xxxxxxxxxxxxxxxxxxxxx", "xxxxxxxxxxxxxxxxxxx"]
const preco = ["200", "150", "130", "120", "170", "300"]
const oferta = ["oferta do dia"]
const gratis = ["Chegará grátis amanhã", "Chegará grátis amanhã", "Chegará grátis amanhã", "Chegará grátis amanhã", "Chegará grátis amanhã", "Chegará grátis amanhã"]
for(let i=0; i < nome.length; i++){
   makita.innerHTML += 
   
`

  <div class="itens">
        <img class="amg" height="180px" width="200px" src=${imagem[i]} alt="">

        <h2 class="tuf">${nome[i]}</h2>
        <p class="tuf">${info[i]}</p>
        <h1 class="tuf">R$ ${preco[i]}</h1>
        <div class="h">
           <p class="tuf">${gratis[i]}</p>
           <img src="./full.png" alt="" srcset="" width="40px" height="40px">
        </div>
    </div>

`
   
}






//for(let i=0; i < nome.length; i++){
//    texto.innerHTML += `<div class= "caixa"> 
//    Nome: ${nome[i]}
//     Idade: ${idade[i]} 
//     <img class=im src = ${imagem[i]}>
//    </div>`;
//}

//const digitar = prompt('digite a caracteristica de uma babaca')
//alert('mo babaca essa ai')